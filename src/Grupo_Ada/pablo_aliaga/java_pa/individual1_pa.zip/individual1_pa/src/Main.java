//individual Pablo Aliaga
public class Main {
    public static void main(String[] args) {
        System.out.println("Inicio");
        System.out.println("Abrir el computador");
        System.out.println("Encender el computador con el botón que tiene a la derecha afuera del teclado");
        System.out.println("En el icono en forma de lupa (o en mac, con la tecla command + espacio) escribir <chrome> o <safari>");
        System.out.println("En el icono que aparezca hacer doble click");
        System.out.println("En la barra horizontal, escribir <www.google.cl> y presionar enter");
        System.out.println("En la barra de la página que cargó, escribir el término que se busca y presionar enter");
        System.out.println("Fin");
    }
}